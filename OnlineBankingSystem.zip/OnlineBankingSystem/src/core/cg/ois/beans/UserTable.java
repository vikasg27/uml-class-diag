package core.cg.ois.beans;

public class UserTable
{
	private int accountId;
	private int userId;
	private String password;
	private String secretQuestion;
	private String transactionPassword;
	private String lockStatus;
	public UserTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserTable(int accountId, int userId, String password,
			String secretQuestion, String transactionPassword, String lockStatus) {
		super();
		this.accountId = accountId;
		this.userId = userId;
		this.password = password;
		this.secretQuestion = secretQuestion;
		this.transactionPassword = transactionPassword;
		this.lockStatus = lockStatus;
	}
	@Override
	public String toString() {
		return "UserTable [accountId=" + accountId + ", userId=" + userId
				+ ", password=" + password + ", secretQuestion="
				+ secretQuestion + ", transactionPassword="
				+ transactionPassword + ", lockStatus=" + lockStatus + "]";
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSecretQuestion() {
		return secretQuestion;
	}
	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}
	public String getTransactionPassword() {
		return transactionPassword;
	}
	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}
	public String getLockStatus() {
		return lockStatus;
	}
	public void setLockStatus(String string) {
		this.lockStatus = string;
	}




}
